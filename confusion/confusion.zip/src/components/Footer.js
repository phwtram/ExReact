import React from 'react';

function Footer() {
  return (
    <footer>
      <p>copyright © 2022</p>
    </footer>
  );
}

export default Footer;





